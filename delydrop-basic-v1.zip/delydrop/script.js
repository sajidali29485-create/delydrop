function getEstimate() {
  const pickup = document.getElementById("pickup").value.trim();
  const drop = document.getElementById("drop").value.trim();
  const result = document.getElementById("result");

  if (!pickup || !drop) {
    result.textContent = "Please enter both pickup and drop locations.";
    result.classList.remove("hidden");
    return;
  }

  const fare = 49;
  result.innerHTML = "Estimated delivery fare: <strong>₹" + fare +
    "</strong><br><small>This is a demo estimate. Real pricing will be connected later.</small>";
  result.classList.remove("hidden");
}

function showMessage(message) {
  alert(message);
}
