# Delydrop

Delydrop is a basic local-delivery app prototype.

## Current version
- Mobile-friendly customer page
- Pickup and drop fields
- Demo delivery fare estimate
- Delydrop branding

## Next versions
- Real login/OTP
- Google Maps or Mapbox
- Driver app
- Live order tracking
- Admin dashboard
- Real pricing
- Online payments

This first version is only a working frontend prototype.
